<? include('shapka_load_style.php'); ?>




<center>


<table width=80%><tr>
<td><center><font size=4><br><strong>Вызовы Вам,  <? echo $name;?></strong><br><br></font></center></td></tr></table>

<br>

<table width=80% ><tr>
<td width=7%></td><td><font size=2><strongl><em><?
echo '<br></td><td width=7%></td></tr>';?>


<tr><td width=7% ></td>

<td bgcolor=#363636 width=28%><br><center>

<? include('./balance.php'); ?>

</center><br></td>



<td bgcolor=#363636 width=28%><br><center>

<? include('./rating.php'); ?>

</center><br></td>


<td bgcolor=#363636 width=28%><br><center>

<? include('./win_loss.php'); ?> 

</center><br></td>


<td width=7% ></td></tr></table>












<table width=80%><tr><td width=7%></td><td><br><center>

<strong><font size=1>Вам предложенные игры:</font></strong>

</center><br></td><td width=7%></td></tr>







<tr><td width=7%></td><td>

<?
include('./opoveshenie/run_game_read.php');
?>

</td><td width=7%></td></tr>





<tr><td width=7%></td><td><br><center>

<? include('./opoveshenie/run_game_clear.php'); ?>

<? if($bg4>'10') { ?>
<strong><font size=1><a href=anketa_run_game.php?rezet=yes>Очистить список вызовов</a> ( Таблица очистится при 60 пунктах )</font></strong>
<? } ?>
</center><br></td><td width=7%></td></tr>




















</table><br></center>